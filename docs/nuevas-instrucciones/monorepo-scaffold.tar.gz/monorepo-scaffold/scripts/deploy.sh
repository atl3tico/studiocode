#!/usr/bin/env bash
# =============================================================================
# deploy.sh — Despliega apps en Vercel
# =============================================================================
# Uso:
#   bash scripts/deploy.sh            → despliega todas las apps
#   bash scripts/deploy.sh landing    → despliega solo landing
#   bash scripts/deploy.sh crm        → despliega solo crm
#   bash scripts/deploy.sh store      → despliega solo store
#   bash scripts/deploy.sh --prod     → todas en producción
# =============================================================================

set -euo pipefail

TARGET=${1:-all}
PROD_FLAG=""
[[ "$*" == *"--prod"* ]] && PROD_FLAG="--prod"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# Verificar Vercel CLI
if ! command -v vercel &>/dev/null; then
  echo "❌ Vercel CLI no encontrado."
  echo "   Instala con: pnpm add -g vercel"
  exit 1
fi

deploy_app() {
  local app=$1
  local app_dir="$ROOT_DIR/apps/$app"

  echo ""
  echo "══════════════════════════════════════════"
  echo "  Desplegando: $app"
  echo "══════════════════════════════════════════"

  if [[ ! -d "$app_dir" ]]; then
    echo "  ❌ No existe el directorio: $app_dir"
    return 1
  fi

  # Build local antes de desplegar
  echo "  🏗️  Build local..."
  cd "$ROOT_DIR"
  pnpm turbo run build --filter="@repo/$app" || {
    echo "  ❌ Build fallido para $app. Corrige los errores antes de desplegar."
    return 1
  }

  # Deploy a Vercel
  echo "  🚀 Desplegando a Vercel..."
  cd "$app_dir"
  vercel $PROD_FLAG --yes 2>/dev/null || vercel $PROD_FLAG

  echo "  ✅ $app desplegado correctamente"
}

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║    DEPLOY — Monorepo Apps                ║"
echo "╚══════════════════════════════════════════╝"

if [[ "$TARGET" == "all" ]]; then
  deploy_app "landing"
  deploy_app "crm"
  deploy_app "store"
elif [[ "$TARGET" == "landing" || "$TARGET" == "crm" || "$TARGET" == "store" ]]; then
  deploy_app "$TARGET"
else
  echo "❌ App '$TARGET' no válida. Opciones: landing, crm, store, all"
  exit 1
fi

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  ✅ Deploy(s) completados                ║"
echo "╚══════════════════════════════════════════╝"
echo ""
echo "🌐 Ver tus deployments: https://vercel.com/dashboard"
echo ""
