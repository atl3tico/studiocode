#!/usr/bin/env bash
# =============================================================================
# new-client.sh — Crea una nueva app de cliente a partir de una app base
# =============================================================================
# Uso: ./scripts/new-client.sh <app> <nombre-cliente>
# Ejemplo: ./scripts/new-client.sh landing acme-corp
#          ./scripts/new-client.sh crm acme-corp
#          ./scripts/new-client.sh store acme-corp
# =============================================================================

set -euo pipefail

APP=${1:-}
CLIENT=${2:-}

# Validar argumentos
if [[ -z "$APP" || -z "$CLIENT" ]]; then
  echo "❌ Error: faltan argumentos."
  echo "   Uso: ./scripts/new-client.sh <app> <nombre-cliente>"
  echo "   Apps disponibles: landing, crm, store"
  exit 1
fi

VALID_APPS=("landing" "crm" "store")
if [[ ! " ${VALID_APPS[*]} " =~ " ${APP} " ]]; then
  echo "❌ Error: app '$APP' no válida. Opciones: landing, crm, store"
  exit 1
fi

# Paths
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
SOURCE_DIR="$ROOT_DIR/apps/$APP"
TARGET_DIR="$ROOT_DIR/clients/apps/$APP/$CLIENT"

# Verificar que la app base existe
if [[ ! -d "$SOURCE_DIR" ]]; then
  echo "❌ Error: la app base '$SOURCE_DIR' no existe."
  echo "   Asegúrate de haber completado la FASE 2/3/4 del PLAN.md"
  exit 1
fi

# Verificar que el cliente no existe ya
if [[ -d "$TARGET_DIR" ]]; then
  echo "⚠️  El cliente '$CLIENT' ya existe en '$TARGET_DIR'"
  read -r -p "   ¿Sobrescribir? [y/N]: " confirm
  if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo "Operación cancelada."
    exit 0
  fi
  rm -rf "$TARGET_DIR"
fi

echo ""
echo "🚀 Creando cliente '$CLIENT' para la app '$APP'..."
echo "   Origen:  $SOURCE_DIR"
echo "   Destino: $TARGET_DIR"
echo ""

# Copiar la app base al directorio del cliente
mkdir -p "$TARGET_DIR"
rsync -a \
  --exclude='node_modules' \
  --exclude='.svelte-kit' \
  --exclude='dist' \
  --exclude='.astro' \
  --exclude='build' \
  --exclude='.turbo' \
  --exclude='.env' \
  "$SOURCE_DIR/" "$TARGET_DIR/"

# Actualizar el nombre del paquete en package.json
PACKAGE_JSON="$TARGET_DIR/package.json"
if [[ -f "$PACKAGE_JSON" ]]; then
  # Reemplazar el name con el nombre del cliente
  sed -i.bak "s|\"name\": \"@repo/$APP\"|\"name\": \"@clients/$APP-$CLIENT\"|g" "$PACKAGE_JSON"
  rm -f "$PACKAGE_JSON.bak"
  echo "✅ package.json actualizado: @clients/$APP-$CLIENT"
fi

# Crear .env a partir de .env.example
ENV_EXAMPLE="$TARGET_DIR/.env.example"
ENV_FILE="$TARGET_DIR/.env"
if [[ -f "$ENV_EXAMPLE" && ! -f "$ENV_FILE" ]]; then
  cp "$ENV_EXAMPLE" "$ENV_FILE"
  echo "✅ .env creado desde .env.example (recuerda completar los valores)"
fi

# Crear CLIENT.md
cat > "$TARGET_DIR/CLIENT.md" << EOF
# Cliente: $CLIENT — App: $APP

Este directorio contiene la versión customizada de \`$APP\` para el cliente **$CLIENT**.

## Origen
Derivado de \`apps/$APP\` el $(date +%Y-%m-%d).

## Customizaciones
> Documenta aquí los cambios específicos de este cliente:
- [ ] Branding (colores, logo, tipografías)
- [ ] Variables de entorno propias
- [ ] Funcionalidades específicas del cliente

## Variables de entorno
Completar \`.env\` con los valores del cliente.

## Deploy en Vercel
\`\`\`bash
cd clients/apps/$APP/$CLIENT
vercel
# Project name: client-${CLIENT}-${APP}
# Build Command: cd ../../../.. && pnpm turbo run build --filter=@clients/$APP-$CLIENT
# Install Command: cd ../../../.. && pnpm install
vercel --prod
\`\`\`

## Ignored Build Step (Vercel dashboard)
\`\`\`bash
git diff HEAD^ HEAD --quiet clients/apps/$APP/$CLIENT/ packages/
\`\`\`
EOF

echo "✅ CLIENT.md creado"

# Crear vercel.json para el cliente
cat > "$TARGET_DIR/vercel.json" << EOF
{
  "buildCommand": "cd ../../../.. && pnpm turbo run build --filter=@clients/$APP-$CLIENT",
  "installCommand": "cd ../../../.. && pnpm install",
  "ignoreCommand": "git diff HEAD^ HEAD --quiet clients/apps/$APP/$CLIENT/ packages/"
}
EOF

echo "✅ vercel.json creado"

echo ""
echo "🎉 Cliente '$CLIENT' creado correctamente en:"
echo "   $TARGET_DIR"
echo ""
echo "📋 Próximos pasos:"
echo "   1. Completar variables en: $TARGET_DIR/.env"
echo "   2. Customizar branding en: $TARGET_DIR/src/"
echo "   3. Documentar cambios en:  $TARGET_DIR/CLIENT.md"
echo "   4. Para desplegar:"
echo "      cd $TARGET_DIR && vercel --prod"
echo ""
