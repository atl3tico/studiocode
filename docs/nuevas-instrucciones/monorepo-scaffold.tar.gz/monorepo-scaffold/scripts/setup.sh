#!/usr/bin/env bash
# =============================================================================
# setup.sh — Setup inicial completo del monorepo
# =============================================================================
# Ejecutar desde la raíz del monorepo: bash scripts/setup.sh
# =============================================================================

set -euo pipefail

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║         MONOREPO — Setup Inicial                     ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ── Verificar prerequisitos ──────────────────────────────────────────────────

echo "🔍 Verificando prerequisitos..."

check_version() {
  local cmd=$1
  local min=$2
  local install_hint=$3
  if ! command -v "$cmd" &>/dev/null; then
    echo "  ❌ $cmd no encontrado. $install_hint"
    return 1
  fi
  echo "  ✅ $cmd disponible"
}

check_version "node" "18" "Instala desde https://nodejs.org"
check_version "pnpm" "8" "Instala con: npm install -g pnpm"
check_version "git" "" "Instala desde https://git-scm.com"

# Turbo (puede estar local o global)
if ! command -v turbo &>/dev/null && ! pnpm list -g turbo &>/dev/null 2>&1; then
  echo "  ⚠️  turbo no encontrado globalmente, se instalará como devDependency"
fi

echo ""
echo "📦 Instalando dependencias del monorepo..."
pnpm install

echo ""
echo "📁 Creando directorios necesarios..."
mkdir -p clients/apps/{landing,crm,store}

echo ""
echo "🏗️  Configurando apps..."

# ── Landing ──────────────────────────────────────────────────────────────────
if [ ! -f "apps/landing/astro.config.mjs" ]; then
  echo ""
  echo "  🚀 Inicializando Landing (Astro)..."
  cd apps/landing
  pnpm create astro@latest . --template minimal --typescript strict --no-install --yes 2>/dev/null || \
    echo "  ⚠️  Astro scaffold falló, inicializa manualmente. Ver README.md"
  pnpm install
  pnpm add -D @astrojs/tailwind tailwindcss
  cd ../..
  echo "  ✅ Landing inicializada"
else
  echo "  ✅ Landing ya existe, saltando"
fi

# ── CRM ──────────────────────────────────────────────────────────────────────
if [ ! -f "apps/crm/svelte.config.js" ]; then
  echo ""
  echo "  🏗️  Clonando CRM (CMSaasStarter)..."
  cd apps/crm
  git clone --depth=1 https://github.com/CriticalMoments/CMSaasStarter.git . 2>/dev/null || \
    echo "  ⚠️  Clone falló. Clona manualmente: git clone https://github.com/CriticalMoments/CMSaasStarter apps/crm"
  rm -rf .git
  # Actualizar nombre del paquete
  sed -i.bak 's/"name": ".*"/"name": "@repo\/crm"/' package.json 2>/dev/null && rm -f package.json.bak
  pnpm install
  pnpm add -D @sveltejs/adapter-vercel
  cd ../..
  echo "  ✅ CRM clonado"
else
  echo "  ✅ CRM ya existe, saltando"
fi

# ── Store ─────────────────────────────────────────────────────────────────────
if [ ! -f "apps/store/svelte.config.js" ]; then
  echo ""
  echo "  🏗️  Clonando Store (sveltekit-medusa-starter)..."
  cd apps/store
  git clone --depth=1 https://github.com/pevey/sveltekit-medusa-starter.git . 2>/dev/null || \
    echo "  ⚠️  Clone falló. Clona manualmente: git clone https://github.com/pevey/sveltekit-medusa-starter apps/store"
  rm -rf .git
  sed -i.bak 's/"name": ".*"/"name": "@repo\/store"/' package.json 2>/dev/null && rm -f package.json.bak
  pnpm install
  pnpm add -D @sveltejs/adapter-vercel
  cd ../..
  echo "  ✅ Store clonado"
else
  echo "  ✅ Store ya existe, saltando"
fi

# ── .env files ───────────────────────────────────────────────────────────────
echo ""
echo "📋 Creando ficheros .env desde .env.example..."
for app in landing crm store; do
  if [ -f "apps/$app/.env.example" ] && [ ! -f "apps/$app/.env" ]; then
    cp "apps/$app/.env.example" "apps/$app/.env"
    echo "  ✅ apps/$app/.env creado"
  fi
done

# ── Permisos de scripts ───────────────────────────────────────────────────────
chmod +x scripts/*.sh

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  ✅ Setup completado                                 ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
echo "📋 Próximos pasos:"
echo "   1. Completa las variables en apps/*/.env"
echo "   2. Actualiza svelte.config.js en crm y store para usar adapter-vercel"
echo "   3. Ejecuta: pnpm dev  (para iniciar todas las apps)"
echo "   4. Cuando estés listo: bash scripts/deploy.sh"
echo ""
echo "📖 Lee PLAN.md para ver el estado completo del proyecto"
echo ""
