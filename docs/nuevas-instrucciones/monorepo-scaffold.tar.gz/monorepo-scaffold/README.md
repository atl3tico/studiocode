# Monorepo

Monorepo con tres apps web: landing, CRM y tienda online.

## Apps

| App | URL local | Framework | Descripción |
|---|---|---|---|
| `landing` | http://localhost:4321 | Astro 4 | Landing pública |
| `crm` | http://localhost:5173 | SvelteKit 2 + Supabase | Panel CRM |
| `store` | http://localhost:5174 | SvelteKit 2 + Medusa | Tienda ecommerce |

## Inicio rápido

```bash
# Requisitos: Node >= 18, pnpm >= 8

# 1. Setup completo (primera vez)
bash scripts/setup.sh

# 2. Completar variables de entorno
# Editar: apps/landing/.env, apps/crm/.env, apps/store/.env

# 3. Iniciar todas las apps
pnpm dev
```

## Comandos

```bash
pnpm dev              # Todas las apps en paralelo
pnpm dev:landing      # Solo landing
pnpm dev:crm          # Solo CRM
pnpm dev:store        # Solo Store
pnpm build            # Build de todo
pnpm build:landing    # Build de landing
```

## Documentación

- **`CLAUDE.md`** — Instrucciones completas para el agente de IA
- **`PLAN.md`** — Estado actual del proyecto y tareas pendientes
- **`apps/landing/README.md`** — Docs de la landing
- **`apps/crm/README.md`** — Docs del CRM
- **`apps/store/README.md`** — Docs de la tienda
- **`clients/apps/README.md`** — Gestión de clientes

## Nuevo cliente

```bash
./scripts/new-client.sh landing acme-corp
./scripts/new-client.sh crm acme-corp
./scripts/new-client.sh store acme-corp
```

## Deploy

```bash
bash scripts/deploy.sh          # Despliega todo
bash scripts/deploy.sh landing  # Solo landing
bash scripts/deploy.sh --prod   # Con flag de producción
```
