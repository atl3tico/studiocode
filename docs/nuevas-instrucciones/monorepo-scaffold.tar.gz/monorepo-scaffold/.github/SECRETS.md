# GitHub Secrets — Configuración

Para que los GitHub Actions workflows funcionen, debes añadir estos secrets
en tu repositorio: Settings → Secrets and variables → Actions

## Secrets requeridos

### Vercel
| Secret | Descripción | Cómo obtenerlo |
|---|---|---|
| `VERCEL_TOKEN` | Token de API de Vercel | vercel.com → Account Settings → Tokens |
| `VERCEL_ORG_ID` | ID de tu organización en Vercel | `vercel whoami` o `.vercel/project.json` |
| `VERCEL_PROJECT_ID_LANDING` | ID del proyecto landing | `.vercel/project.json` dentro de `apps/landing` después de `vercel` |
| `VERCEL_PROJECT_ID_CRM` | ID del proyecto CRM | `.vercel/project.json` dentro de `apps/crm` |
| `VERCEL_PROJECT_ID_STORE` | ID del proyecto store | `.vercel/project.json` dentro de `apps/store` |

### Supabase (para el CI del CRM)
| Secret | Descripción |
|---|---|
| `PUBLIC_SUPABASE_URL` | URL del proyecto Supabase |
| `PUBLIC_SUPABASE_ANON_KEY` | Anon/public key de Supabase |

### Medusa (para el CI del Store)
| Secret | Descripción |
|---|---|
| `PUBLIC_MEDUSA_BACKEND_URL` | URL del backend Medusa desplegado |

### Turborepo Remote Cache (opcional pero recomendado)
| Secret | Descripción | Cómo obtenerlo |
|---|---|---|
| `TURBO_TOKEN` | Token para remote caching | vercel.com → Turborepo |
| `TURBO_TEAM` | Nombre del team en Turbo | vercel.com → Turborepo |

## Cómo obtener los IDs de Vercel

Después de hacer el primer deploy con Vercel CLI:

```bash
# Para landing:
cat apps/landing/.vercel/project.json
# → {"orgId":"xxx","projectId":"yyy"}

# Para crm:
cat apps/crm/.vercel/project.json

# Para store:
cat apps/store/.vercel/project.json
```

## Añadir secrets con GitHub CLI

```bash
gh secret set VERCEL_TOKEN --body "tu-token"
gh secret set VERCEL_ORG_ID --body "tu-org-id"
gh secret set VERCEL_PROJECT_ID_LANDING --body "prj_xxx"
gh secret set VERCEL_PROJECT_ID_CRM --body "prj_yyy"
gh secret set VERCEL_PROJECT_ID_STORE --body "prj_zzz"
```
