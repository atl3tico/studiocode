# clients/apps/ — Versiones por Cliente

Este directorio almacena copias customizadas de cada app para clientes específicos.

## Estructura

```
clients/apps/
├── landing/
│   ├── demo-client/       ← Cliente de ejemplo
│   └── <tu-cliente>/
├── crm/
│   ├── demo-client/
│   └── <tu-cliente>/
└── store/
    ├── demo-client/
    └── <tu-cliente>/
```

## Crear un nuevo cliente

```bash
# Desde la raíz del monorepo:
./scripts/new-client.sh landing <nombre-cliente>
./scripts/new-client.sh crm <nombre-cliente>
./scripts/new-client.sh store <nombre-cliente>
```

## Reglas importantes

1. **Nunca modifiques las apps base** en `apps/`. Las customizaciones van solo aquí.
2. Cada carpeta de cliente tiene su propio `CLIENT.md` con los cambios documentados.
3. Cada cliente tiene sus propias variables de entorno (`.env` no se commitea).
4. Para desplegar un cliente en Vercel, cada carpeta tiene su propio `vercel.json`.

## Desplegar un cliente

```bash
cd clients/apps/<app>/<cliente>
vercel --prod
```

## Convención de nombres en Vercel

Usa el patrón: `client-<nombre-cliente>-<app>`

Ejemplos:
- `client-acme-landing`
- `client-acme-crm`
- `client-globex-store`
