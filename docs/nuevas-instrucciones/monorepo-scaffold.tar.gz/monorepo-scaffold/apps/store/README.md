# Store — @repo/store

Storefront de ecommerce construido con **SvelteKit 2** y **Medusa v2**.
Basado en [sveltekit-medusa-starter](https://github.com/pevey/sveltekit-medusa-starter).

## Setup inicial (primera vez)

```bash
# 1. Clonar el repo base en esta carpeta
cd apps/store
git clone https://github.com/pevey/sveltekit-medusa-starter.git .
rm -rf .git

# 2. Actualizar package.json — cambiar "name" a "@repo/store"

# 3. Instalar adapter de Vercel
pnpm add -D @sveltejs/adapter-vercel

# 4. En svelte.config.js, cambiar adapter a adapter-vercel

# 5. Copiar variables de entorno
cp .env.example .env
```

## Backend Medusa (local)

El store necesita un backend Medusa corriendo:

```bash
# En un directorio separado (fuera del monorepo):
npx create-medusa-app@latest medusa-backend
cd medusa-backend
yarn dev
# → http://localhost:9000
```

Luego en `apps/store/.env`:
```
MEDUSA_BACKEND_URL=http://localhost:9000
PUBLIC_MEDUSA_BACKEND_URL=http://localhost:9000
```

También añadir el dominio del store al CORS del backend Medusa:
```js
// medusa-config.js del backend:
store_cors: process.env.STORE_CORS || "http://localhost:5174"
```

## Desarrollo

```bash
# Desde la raíz del monorepo:
pnpm dev:store
# → http://localhost:5174
```

## Deploy

Ver instrucciones detalladas en `/CLAUDE.md` → FASE 6.4

> ⚠️ El backend Medusa necesita estar desplegado antes de desplegar el store.
> Opciones recomendadas: Railway, Render, o Digital Ocean App Platform.
