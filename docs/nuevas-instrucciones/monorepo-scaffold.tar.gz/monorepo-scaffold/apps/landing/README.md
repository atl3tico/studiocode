# Landing — @repo/landing

App de landing pública construida con **Astro 4** y **Tailwind CSS**.

## Setup

```bash
# Desde la raíz del monorepo:
pnpm install

# Copiar variables de entorno
cp apps/landing/.env.example apps/landing/.env

# Iniciar dev server (puerto 4321)
pnpm dev:landing
```

## Inicializar Astro (si la carpeta está vacía)

```bash
cd apps/landing
pnpm create astro@latest . --template minimal --typescript strict --no-install
pnpm install
pnpm add -D @astrojs/tailwind tailwindcss
```

## Estructura

```
src/
├── components/      ← Componentes .astro reutilizables
├── layouts/
│   └── Layout.astro ← Layout base
└── pages/
    ├── index.astro  ← Homepage
    ├── about.astro
    └── contact.astro
```

## Deploy

Ver instrucciones detalladas en `/CLAUDE.md` → FASE 6.2
