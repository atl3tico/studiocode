# CRM — @repo/crm

App CRM construida con **SvelteKit 2**, **Supabase** y **Tailwind + DaisyUI**.
Basado en [CMSaasStarter](https://github.com/CriticalMoments/CMSaasStarter).

## Setup inicial (primera vez)

```bash
# 1. Clonar el repo base en esta carpeta
cd apps/crm
git clone https://github.com/CriticalMoments/CMSaasStarter.git .
rm -rf .git

# 2. Actualizar package.json — cambiar "name" a "@repo/crm"

# 3. Instalar adapter de Vercel
pnpm add -D @sveltejs/adapter-vercel

# 4. En svelte.config.js, cambiar:
#    import adapter from '@sveltejs/adapter-auto'
#    → import adapter from '@sveltejs/adapter-vercel'

# 5. Copiar y completar variables de entorno
cp .env.example .env
```

## Desarrollo

```bash
# Desde la raíz del monorepo:
pnpm dev:crm
# → http://localhost:5173
```

## Supabase — pasos obligatorios

1. Crear proyecto en https://supabase.com
2. Copiar URL y keys en `.env`
3. Ejecutar migraciones (si CMSaasStarter las incluye):
   ```bash
   pnpm supabase db push
   ```
4. En Supabase → Auth → URL Configuration:
   - Site URL: `http://localhost:5173` (dev) / URL de Vercel (prod)

## Deploy

Ver instrucciones detalladas en `/CLAUDE.md` → FASE 6.3
